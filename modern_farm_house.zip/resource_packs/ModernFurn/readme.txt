-----------------------------------------------------------------
MODERN FURNITURE ADDON by KRAFTOID
VERSION 1
Created on June 23, 2021
Available through MCPEDL.com 

Changelog: Official release. 
Additions include two new elements & changes include minor changes with the existing model textures. Redundant code on the packs are removed.

Note: Models & textures can't be used without permission. Feel free to check code as a reference for your project or work.
We've added a Trailer!
-----------------------------------------------------------------