Hello kind reader! Vlad here.

I made this pack as a means of achieving features that many Marketplace maps have been using to make their experience more immersive. You are free to use this pack in any project you like, and modify the images and hud_screen.json file. A credit would be nice, of course, but you are free not to, as I am glad to push the community forward!


Here are all the title commands available (the commands also work with the Safe Area set to a value smaller than 100):

► /title @p title hud hide
Hides all the HUD elements (chat, hotbar, xp bar, hearts, hunger, horse hearts, horse power jump) apart from the hand.

► /title @p title hud show
Shows all the HUD elements back. Ideally useful after "/title @p title title" or "/title @p title hud hide"

► /title @p title title
Will display a title image that will stay on screen for as long as you define it with the "/title <targets> times <fadeIn> <stay> <fadeOut>" command. This command also hides the HUD (hotbar, chat etc.)

► /title @p title subtitle
Will display a title image that will stay on screen for as long as you define it with the "/title <targets> times <fadeIn> <stay> <fadeOut>" command.

► /title @p title blink
The screen fades to black and then fades out again.

► /title @p title blink slow in
The screen fades to black slowly, remaining this way until another title command is executed.

► /title @p title blink slow out
The screen fades out from black slowly.

► /title @p actionbar bars in
Top and bottom black bars slide in, creating a cinematic feel. Very useful for cutscenes. Combine with "/title @p title hud hide" to creat an even more immersive feel. Another suggestion would be to use invisibility if you want to hide the player's hand.

► /title @p actionbar bars out
Top and bottom black bars slide out.

► /title @p actionbar subtitle 
If you want to run actionbar title commands while the black bars are shown, you have to preceed any text with "subtitle ". Otherwise, the actionbar text will cause the black bars to disappear