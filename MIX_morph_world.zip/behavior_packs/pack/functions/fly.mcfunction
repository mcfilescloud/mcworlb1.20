execute @a[tag=fly,rx=90,rxm=0] ~ ~ ~ effect @s slow_falling 1 1 true
execute @a[tag=fly,rx=3,rxm=-10] ~ ~ ~ effect @s levitation 1 1 true
execute @a[tag=fly,rx=-10,rxm=-35] ~ ~ ~ effect @s levitation 1 3 true
execute @a[tag=fly,rx=-35,rxm=-90] ~ ~ ~ effect @s levitation 1 6 true


