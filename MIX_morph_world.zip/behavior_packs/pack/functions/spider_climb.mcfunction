### The function to make the player as a spider clim the walls
### This will be activated by the trigger tool.
### /function spider_climb


### Test for x+1
execute @s ~ ~ ~ detect ~1 ~ ~ air 0 tag @s add cant_climb
execute @s[tag=!cant_climb] ~ ~ ~ tag @s add can_climb 
tag @s remove cant_climb

### Test for x-1
execute @s ~ ~ ~ detect ~-1 ~ ~ air 0 tag @s add cant_climb
execute @s[tag=!cant_climb] ~ ~ ~ tag @s add can_climb 
tag @s remove cant_climb

### Test for z+1
execute @s ~ ~ ~ detect ~ ~ ~+1 air 0 tag @s add cant_climb
execute @s[tag=!cant_climb] ~ ~ ~ tag @s add can_climb 
tag @s remove cant_climb

### Test for z-1
execute @s ~ ~ ~ detect ~ ~ ~-1 air 0 tag @s add cant_climb
execute @s[tag=!cant_climb] ~ ~ ~ tag @s add can_climb 
tag @s remove cant_climb

### Only add the effect if we are allowed to climb
effect @s[tag=can_climb] levitation 1 1 true
effect @s[tag=!can_climb] clear
tag @s remove can_climb

