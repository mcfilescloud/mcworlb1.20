// scripts/index.ts
import { BlockPermutation, system } from "@minecraft/server";

// scripts/itemEvents/index.ts
import { world } from "@minecraft/server";
var ItemEventHandler = class {
  constructor(itemName) {
    this.itemName = itemName;
  }
  events = /* @__PURE__ */ new Map();
  after(eventName, callback) {
    ItemEvent.initializeAfterEventListener(eventName);
    const eventNameId = `after:${eventName}`;
    if (!this.events.has(eventNameId))
      this.events.set(eventNameId, []);
    const eventArray = this.events.get(eventNameId);
    if (eventArray === void 0)
      throw new Error("Event array is undefined");
    eventArray.push(callback);
    return this;
  }
  before(eventName, callback) {
    ItemEvent.initializeBeforeEventListener(eventName);
    const eventNameId = `before:${eventName}`;
    if (!this.events.has(eventNameId))
      this.events.set(eventNameId, []);
    const eventArray = this.events.get(eventNameId);
    if (eventArray === void 0)
      throw new Error("Event array is undefined");
    eventArray.push(callback);
    return this;
  }
};
var ItemEvent = class _ItemEvent {
  /**
   * A map of item event handlers.
   */
  static itemHandlers = /* @__PURE__ */ new Map();
  /**
   * An array of event names that have been initialized for after listeners.
   */
  static afterListenersInitiated = [];
  /**
   * An array of event names that have been initialized for before listeners.
   */
  static beforeListenersInitiated = [];
  /**
   * Initializes an after event listener for the specified event name.
   * @param eventName The name of the event to initialize.
   * @returns void
   */
  static initializeAfterEventListener(eventName) {
    if (_ItemEvent.afterListenersInitiated.includes(eventName))
      return;
    _ItemEvent.afterListenersInitiated.push(eventName);
    world.afterEvents[eventName].subscribe((e) => {
      const itemHandlers = _ItemEvent.itemHandlers.get(e.itemStack.typeId);
      if (itemHandlers === void 0)
        return;
      for (const itemHandler of itemHandlers) {
        const eventArray = itemHandler.events.get(`after:${eventName}`);
        if (eventArray === void 0)
          continue;
        for (const event of eventArray) {
          event(e);
        }
      }
    });
  }
  /**
   * Initializes an after event listener for the specified event name.
   * @param eventName The name of the event to initialize.
   * @returns void
   */
  static initializeBeforeEventListener(eventName) {
    if (_ItemEvent.afterListenersInitiated.includes(eventName))
      return;
    _ItemEvent.afterListenersInitiated.push(eventName);
    world.beforeEvents[eventName].subscribe((e) => {
      const itemHandlers = _ItemEvent.itemHandlers.get(e.itemStack.typeId);
      if (itemHandlers === void 0)
        return;
      for (const itemHandler of itemHandlers) {
        const eventArray = itemHandler.events.get(`before:${eventName}`);
        if (eventArray === void 0)
          continue;
        for (const event of eventArray) {
          event(e);
        }
      }
    });
  }
  /**
   * Returns an ItemEventHandler for the specified item name.
   * @param itemName The name of the item to create an event handler for.
   * @returns An ItemEventHandler instance.
   */
  static item(itemName) {
    const itemHandler = new ItemEventHandler(itemName);
    this.itemHandlers.set(itemName, [...this.itemHandlers.get(itemName) ?? [], itemHandler]);
    return itemHandler;
  }
};
world.beforeEvents.itemUse.subscribe((e) => {
});
var coffeeItem = ItemEvent.item("tl:coffee").after("itemCompleteUse", (e) => {
});
var itemEvents_default = ItemEvent;

// scripts/Vector3.ts
var VectorUtils = class _VectorUtils {
  /**
   * Returns an array of Vector3 objects with the given offsets applied to the input Vector3 object.
   * @param v1 - The input Vector3 object.
   * @param offsets - An object containing the offsets to be applied to the input Vector3 object.
   * @returns An array of Vector3 objects with the given offsets applied to the input Vector3 object.
   */
  static offsets(v1, offsets) {
    const finalArr = [];
    for (const v of offsets) {
      const v1copy = { ...v1 };
      for (const k in v) {
        v1copy[k] += v[k];
      }
      finalArr.push(v1copy);
    }
    return finalArr;
  }
  /**
  * Iterates through the given vector and returns a new vector with the values processed by the callback function.
  * @param v The vector to iterate through.
  * @param callback A callback function that will be called for each key-value pair in the vector.
  * @returns The processed vector.
  */
  static forEach(v, callback) {
    const copy = { ...v };
    for (const k in copy) {
      copy[k] = callback(k, copy[k]);
    }
    return copy;
  }
  static isVector3(v) {
    return typeof v === "object" && typeof v.x === "number" && typeof v.y === "number" && typeof v.z === "number";
  }
  static isVector2(v) {
    return typeof v === "object" && typeof v.x === "number" && typeof v.y === "number";
  }
  static add(v1, v2) {
    return _VectorUtils.forEach(v1, (k, v) => v + v2[k]);
  }
  static subtract(v1, v2) {
    return _VectorUtils.forEach(v1, (k, v) => v - v2[k]);
  }
  static multiply(v1, multiplier) {
    return _VectorUtils.forEach(v1, (k, v) => v * multiplier);
  }
  static round(v) {
    return _VectorUtils.forEach(v, (k, v2) => Math.round(v2));
  }
  static floor(v) {
    return _VectorUtils.forEach(v, (k, v2) => Math.floor(v2));
  }
  static ceil(v) {
    return _VectorUtils.forEach(v, (k, v2) => Math.ceil(v2));
  }
  static divide(v1, divider) {
    return _VectorUtils.forEach(v1, (k, v) => v / divider);
  }
};
var Vector3_Utils = class _Vector3_Utils extends VectorUtils {
  static distance(v1, v2) {
    const x = v1.x - v2.x;
    const y = v1.y - v2.y;
    const z = v1.z - v2.z;
    return Math.sqrt(x * x + y * y + z * z);
  }
  static equals(v1, v2) {
    return v1.x === v2.x && v1.y === v2.y && v1.z === v2.z;
  }
  // Returns the center of the block that the given vector is in, centering all the axes except the ones avoided.
  static getBlockCenter(v, avoidAxes) {
    const floorVector = _Vector3_Utils.floor(v);
    for (const k in floorVector) {
      if (avoidAxes && avoidAxes[k])
        continue;
      floorVector[k] += 0.5;
    }
    return floorVector;
  }
  static getBlockCenterExceptY(v) {
    const floorVector = _Vector3_Utils.floor(v);
    for (const k in floorVector) {
      if (k === "y")
        continue;
      floorVector[k] += 0.5;
    }
    return floorVector;
  }
};
var Vector3_default = Vector3_Utils;

// scripts/index.ts
itemEvents_default.item("tl:coffee").after("itemCompleteUse", (e) => {
  e.source.addEffect("speed", 10 * 20, {
    amplifier: 1
  });
});
var isTeleporting = [];
system.afterEvents.scriptEventReceive.subscribe((e) => {
  if (e.sourceEntity === void 0 || e.message !== "pickup")
    return;
  if (isTeleporting.includes(e.sourceEntity))
    return;
  const playerArr = e.sourceEntity.dimension.getEntities({
    location: e.sourceEntity.location,
    closest: 1,
    type: "minecraft:player"
  });
  const entity = e.sourceEntity;
  if (playerArr.length === 0)
    return;
  const player = playerArr[0];
  isTeleporting.push(entity);
  const inter = system.runInterval(() => {
    if (player.isSneaking || !entity.isValid()) {
      isTeleporting.splice(isTeleporting.indexOf(player), 1);
      return system.clearRun(inter);
    }
    const location = (() => {
      const rot = player.getRotation();
      const lookingDir = Math.round(-rot.y / 180 * Math.PI * 1e5) / 1e5;
      const z = Math.cos(lookingDir);
      const x = Math.sin(lookingDir);
      return Vector3_default.add(player.location, { x, y: 1, z });
    })();
    entity.teleport(location, {
      facingLocation: player.location
    });
  }, 0);
});
system.afterEvents.scriptEventReceive.subscribe((e) => {
  if (!e.sourceEntity || !(e.sourceEntity.typeId ?? "").startsWith("tl:ceiling_fan"))
    return;
  if (e.message === "light" && e.sourceEntity !== void 0) {
    const b = e.sourceEntity.dimension.getBlock(e.sourceEntity.location);
    if (b?.permutation.matches("minecraft:air")) {
      b.setPermutation(BlockPermutation.resolve("light_block", {
        block_light_level: 15
      }));
    } else if (b?.permutation.matches("light_block")) {
      b.setPermutation(BlockPermutation.resolve("minecraft:air"));
    }
    return;
  }
  e.sourceEntity.setProperty("tl:fan_enabled", !e.sourceEntity.getProperty("tl:fan_enabled"));
});
