import { world as run, system as sys, MolangVariableMap, EntityComponentTypes as mob, Player } from "@minecraft/server";
const anomaliBrainrot = {
	tung_sahur: [ 'anomali.tung_sahur', 75, 1, 0.48, 0.13],
	tralala: ['anomali.tralalero', 30, 0.13, 0.7, 1],
	udindindindun: ['anomali.udindindindun', 65, 1, 0.48, 0.13],
	chimpanzini_bananini: ['anomali.chimpanzini_bananini', 35, 0.13, 1, 0.13],
	brr_patapim: [ 'anomali.brr_patapim', 55, 1, 0.48, 0.13],
	boneca_ambalabu: [ 'anomali.boneca_ambalabu', 40, 0.13, 1, 0.13],
	bombardiro_crocodilo: [ 'anomali.bombardiro_crocodilo', 41, 1, 0.48, 0.13],
	la_vaca_saturnito: [ 'anomali.la_vaca_saturnito', 42, 0.7, 0.7, 0.7],
	frigo_camel: [ 'anomali.frigo_camel', 42, 0.7, 0.7, 0.7],
	cappucino_assasino: [ 'anomali.cappucino_assasino', 80, 1, 0.48, 0.13]
};
function handleBrainrotSound(entity) {
  Object.entries(anomaliBrainrot).forEach(([a, b]) => {
    if (entity.typeId === `pa:${a}`) {
      const playSoundNearby = () => {
        for (const player of run.getPlayers()) {
          const playerLoc = player.location, entityLoc = entity.location,
                dx = entityLoc.x - playerLoc.x, dy = entityLoc.y - playerLoc.y, dz = entityLoc.z - playerLoc.z,
                distance = Math.sqrt(dx * dx + dy * dy + dz * dz),
                volume = Math.max(0.1, 1.6 - (distance / 16) * (1.6 - 0.1)) / 1.5;
          if (distance <= 16) {
            player.playSound(b[0], {
              volume: parseFloat(volume.toFixed(2))
            });
          }
        }
      };
      playSoundNearby();
      const makeSounds = sys.runInterval(() => {
        if (!entity.isValid()) {
          sys.clearRun(makeSounds);
          return;
        }
        playSoundNearby();
      }, parseFloat(b[1]));
    }
  });
};
function handleAnomaliHit(subject, enemy, partLoc) {
if (!enemy.isValid()) return;
        if (enemy instanceof Player) return;
    Object.entries(anomaliBrainrot).forEach(([a, d]) => {
        if (subject.typeId !== `pa:${a}`) return;

        const color = new MolangVariableMap();
        color.setColorRGB('color', { red: d[2], green: d[3], blue: d[4] });

        partLoc.dimension.spawnParticle("pa:pa_hitting_particle", partLoc.location, color);

        let c = enemy.getComponent(mob.Health),
            b = subject.getComponent(mob.Health);

        b.setCurrentValue(b.currentValue + c.currentValue);

        enemy.dimension.playSound('anomali.keywoo', enemy.location);
        enemy.dimension.spawnParticle("pa:keywoo_particle", enemy.location);
        enemy.remove();
    });
};
run.afterEvents.entityHitEntity.subscribe((e) => {
    const {damagingEntity: subject, hitEntity: enemy} = e,
    partLoc = subject;
    handleAnomaliHit(subject, enemy, partLoc)
});
run.afterEvents.projectileHitEntity.subscribe((ef) => {
const {
		source: subject,
		projectile: bullet,
	} = ef, enemy = ef.getEntityHit()?.entity,
	partLoc = enemy;
handleAnomaliHit(subject, enemy, partLoc)
});
run.afterEvents.entityLoad.subscribe(({entity}) => {
    handleBrainrotSound(entity);
}); 
run.afterEvents.entitySpawn.subscribe(({entity}) => {
    handleBrainrotSound(entity);
}); 