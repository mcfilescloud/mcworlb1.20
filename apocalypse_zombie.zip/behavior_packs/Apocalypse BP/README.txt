This map is published on MCPEDL and will only be here. It is not allowed to be published on any other websites or Minecraft Add-On applications without my (JuliusScizzor's) permission.

If you are using this map for your content (YouTube videos, etc.), all I ask is for you to link this MCPEDL page in your video descriptions and/or link to my YouTube channel.

You are NOT allowed to edit the code or use any of the assets WITHOUT my permission. Learning from the code is fine, but blatant copying is NOT learning. If you want some images for fan-art, etc, PLEASE contact me on Discord.

Show your support by sharing this map and my videos!

Music belongs to Krypt, DO NOT USE WITHOUT HIS PERMISSION

Copyright 2023 JuliusScizzor