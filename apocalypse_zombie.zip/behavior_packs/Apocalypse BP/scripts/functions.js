import {
    GameMode,
    world,
    Player,
    system,
  } from "@minecraft/server";

  
export function getGamemode(player) {
    return Object.values(GameMode).find((g) => [...world.getPlayers({ name: player.name, gameMode: g })].length);
}