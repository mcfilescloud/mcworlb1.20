
      Copyright 2019 @GabrielCas29007

///// If you are reading these files, it is because you are accessing them, YOU HAVE NO AUTHORIZATION TO MODIFY OR COPY THEM, so any indication that this has been done will be due to Gabriel Castro, the creator of the yCreatures add-on./////

/////Se você esta lendo estes arquivos, é porque esta os acessando, VOCÊ NAO TEM AUTORIZAÇAO PARA MODIFICA-LOS OU COPIA-LOS, portanto qualquer indício deque isto foi realizado, serão cobrados os devidos direitos para Gabriel Castro, o criador do complemento yCreatures/////

/////Si está leyendo estos archivos, es porque está accediendo a ellos, NO TIENE AUTORIZACIÓN PARA MODIFICARLOS O COPIARLOS, por lo que cualquier indicación de que esto se haya hecho se debe a Gabriel Castro, el creador del complemento yCreatures./////

****Copying, modifying, or using the files in this add-on is subject to COPYRIGHT, so do not do it!
Viewing codes are allowed as long as they are not copied, modified, or exported to another add-on.

The templates, and textures are unique to yCreatures, and their use will also charge you copyright.

For more questions ask: @ GabrielCas29007****

□Copyright, All Rights Reserved. 