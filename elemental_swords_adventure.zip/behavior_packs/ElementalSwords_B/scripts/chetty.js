/**
 * ===== ELEMENTAL SWORDS =====
 * 
 * By O CHETTY O
*/

import { world } from "@minecraft/server";
world.events.beforeItemUse.subscribe(detectPet);

function detectPet(data) {

	const dimensions = world.getDimension("overworld") || world.getDimension("nether") || world.getDimension("the end");
	const entities = Array.from(dimensions.getEntities());
	const { item } = data;
	const swords = [
		"chetty:airsword",
		"chetty:earthsword",
		"chetty:icesword",
		"chetty:lightningsword"
	];

	for (const items in swords) {
		if (item.typeId === swords[items]) {
			for (const pet of entities) {
				if (pet.dimension === dimensions && pet.hasComponent("is_tamed") === true) {
					pet.addTag("ice");
					pet.addTag("earth");
					pet.addTag("air");
					pet.addTag("lightning");
				}
			}
		}
	}
}
