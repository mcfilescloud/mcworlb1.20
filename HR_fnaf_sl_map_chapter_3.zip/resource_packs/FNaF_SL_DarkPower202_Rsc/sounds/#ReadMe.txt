With the sounds.json and sound_definitions.json, we can
add custom sounds instead of replacing them by adding some keys to it.



I've been working on this since the release of my FNaF: SL Night 2 map.


Please add my name in the credits if you learned it from here, thanks.




Contains contents from the original FNaF: SL game.

- DarkPower202

