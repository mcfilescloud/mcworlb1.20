Textures by DarkPower202, source from Google Image Search.


Contains some contents from the original FNaF: SL game.



Animated textures are made by stacking images by images
horizontally and adding lines to flipbook_textures.json.



(256x256 Texture Pack)



NOT FOR PUBLIC RELEASE!